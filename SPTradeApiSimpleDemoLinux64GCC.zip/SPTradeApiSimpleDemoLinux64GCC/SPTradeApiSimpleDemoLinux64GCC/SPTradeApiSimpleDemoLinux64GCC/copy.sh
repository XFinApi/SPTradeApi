#!/bin/sh
cp -r ../../TradeApi_linux64 ./